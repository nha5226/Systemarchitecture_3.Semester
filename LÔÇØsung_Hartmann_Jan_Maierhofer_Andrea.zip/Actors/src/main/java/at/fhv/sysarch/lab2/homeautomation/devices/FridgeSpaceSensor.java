package at.fhv.sysarch.lab2.homeautomation.devices;


import akka.actor.typed.ActorRef;
import akka.actor.typed.Behavior;
import akka.actor.typed.PostStop;
import akka.actor.typed.javadsl.AbstractBehavior;
import akka.actor.typed.javadsl.ActorContext;
import akka.actor.typed.javadsl.Behaviors;
import akka.actor.typed.javadsl.Receive;

import java.util.Optional;

public class FridgeSpaceSensor extends AbstractBehavior<FridgeSpaceSensor.FridgeSpaceCommand> {

    public interface FridgeSpaceCommand {}

    public static final class AddSpace implements FridgeSpaceCommand {
        final Optional<Integer> additionalSpace;
        final ActorRef<OrderProcessor.OrderProcessorCommand> orderProcessor;

        public AddSpace(Optional<Integer> additionalSpace, ActorRef<OrderProcessor.OrderProcessorCommand> orderProcessor) {
            this.additionalSpace = additionalSpace;
            this.orderProcessor = orderProcessor;
        }
    }

    public static final class SubSpace implements FridgeSpaceCommand {
        final Optional<Integer> subtractionalSpace;
        final ActorRef<OrderProcessor.OrderProcessorCommand> orderProcessor;

        public SubSpace(Optional<Integer> subtractionalSpace, ActorRef<OrderProcessor.OrderProcessorCommand> orderProcessor) {
            this.subtractionalSpace = subtractionalSpace;
            this.orderProcessor = orderProcessor;
        }
    }

    public static final class Space implements FridgeSpaceCommand {
        final ActorRef<Fridge.FridgeCommand> fridge;

        public Space(ActorRef<Fridge.FridgeCommand> fridge) {
            this.fridge = fridge;
        }


    }

    public static Behavior<FridgeSpaceCommand> create( String groupID, String deviceID) {
        return Behaviors.setup(context -> new FridgeSpaceSensor(context, groupID, deviceID));
    }

    private final String groupID;
    private final String deviceID;
    private Integer space = 0;

    public FridgeSpaceSensor(ActorContext<FridgeSpaceCommand> context, String groupID, String deviceID) {
        super(context);
        this.groupID = groupID;
        this.deviceID = deviceID;

        getContext().getLog().info("FridgeSpaceSensor started");
    }

    @Override
    public Receive<FridgeSpaceCommand> createReceive() {
        return newReceiveBuilder()
                .onMessage(AddSpace.class, this::onAddSpace)
                .onMessage(SubSpace.class, this::onSubSpace)
                .onMessage(Space.class, this::onSpace)
                .onSignal(PostStop.class, signal -> onPostStop())
                .build();
    }

    private Behavior<FridgeSpaceCommand> onAddSpace(AddSpace a) {
        getContext().getLog().info("FridgeSpace increases {}", a.additionalSpace.get());
        Integer spaceOfNewProduct = a.additionalSpace.get();
        space = space + spaceOfNewProduct;
        Optional<Integer> newSpace = Optional.of(space);
        a.orderProcessor.tell(new OrderProcessor.ResponseFromSpaceSensor());
        return this;
    }

    private Behavior<FridgeSpaceCommand> onSubSpace(SubSpace s) {
        getContext().getLog().info("FridgeSpace decreases {}", s.subtractionalSpace.get());
        Integer spaceOfNewProduct = s.subtractionalSpace.get();
        space = space - spaceOfNewProduct;
        Optional<Integer> newSpace = Optional.of(space);
        s.orderProcessor.tell(new OrderProcessor.ResponseFromSpaceSensor());
        return this;
    }

    public Behavior<FridgeSpaceCommand> onSpace(Space s) {
        s.fridge.tell(new Fridge.SpaceCommand(Optional.of(space)));
        return this;
    }


    private FridgeSpaceSensor onPostStop() {
        getContext().getLog().info("FridgeSpaceSensor actor {}-{} stopped", groupID, deviceID);
        return this;
    }

}
