package at.fhv.sysarch.lab2.homeautomation.fridge;

import java.math.BigDecimal;
import java.util.Objects;

public class Product {
    private String productname;
    private double weight;
    private BigDecimal productprice;

    public Product(String productname, double weight, BigDecimal productprice) {
        this.productname = productname;
        this.weight = weight;
        this.productprice = productprice;
    }

    public String getProductname() {
        return productname;
    }

    public void setProductname(String productname) {
        this.productname = productname;
    }

    public double getWeight() {
        return weight;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }

    public BigDecimal getProductprice() {
        return productprice;
    }

    public void setProductprice(BigDecimal productprice) {
        this.productprice = productprice;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Product product = (Product) o;
        return Double.compare(product.weight, weight) == 0 && Objects.equals(productname, product.productname) && Objects.equals(productprice, product.productprice);
    }

    @Override
    public int hashCode() {
        return Objects.hash(productname, weight, productprice);
    }

    @Override
    public String toString(){
        return "Productname: " + productname + " Weight: " + weight + " Price: " + productprice;
    }


}
