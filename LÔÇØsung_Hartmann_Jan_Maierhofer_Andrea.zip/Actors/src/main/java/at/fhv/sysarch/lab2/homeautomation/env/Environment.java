package at.fhv.sysarch.lab2.homeautomation.env;

import akka.actor.typed.ActorRef;
import akka.actor.typed.Behavior;
import akka.actor.typed.PostStop;
import akka.actor.typed.javadsl.*;
import at.fhv.sysarch.lab2.homeautomation.devices.TemperatureSensor;
import at.fhv.sysarch.lab2.homeautomation.devices.WeatherSensor;

import java.time.Duration;
import java.util.Optional;

public class Environment extends AbstractBehavior<Environment.EnvironmentCommand> {

    public interface EnvironmentCommand {}




    public static final class TemperatureChanger implements EnvironmentCommand {
        final Optional<Double> value;

        public TemperatureChanger(Optional<Double> value) {
            this.value = value;
        }
    }

    public static final class WeatherConditionsChanger implements EnvironmentCommand {
        final Optional<Boolean> isSunny;

        public WeatherConditionsChanger(Optional<Boolean> isSunny) {
            this.isSunny = isSunny;
        }
    }

    public static final class InitEnvironment implements EnvironmentCommand {

    }

    private ActorRef<WeatherSensor.WeatherSensorCommand> weatherSensor;
    private ActorRef<TemperatureSensor.TemperatureCommand> temperatureSensor;

    private double temperature = 15.0;
    private boolean isSunny = false;
    private boolean setHighTemp = false;
    private boolean setLowTemp = true;

    private final TimerScheduler<EnvironmentCommand> temperatureTimeScheduler;
    private final TimerScheduler<EnvironmentCommand> weatherTimeScheduler;


    public static Behavior<EnvironmentCommand> create(ActorRef<WeatherSensor.WeatherSensorCommand> weatherSensor, ActorRef<TemperatureSensor.TemperatureCommand> temperatureSensor){
        return Behaviors.setup(context ->  Behaviors.withTimers(timers -> new Environment(context, timers, timers, weatherSensor, temperatureSensor)));
    }

    private Environment(ActorContext<EnvironmentCommand> context,TimerScheduler<EnvironmentCommand> tempTimer, TimerScheduler<EnvironmentCommand> weatherTimer, ActorRef<WeatherSensor.WeatherSensorCommand> weatherSensor, ActorRef<TemperatureSensor.TemperatureCommand> temperatureSensor) {
        super(context);
        this.temperatureSensor = temperatureSensor;
        this.weatherSensor = weatherSensor;
        this.temperatureTimeScheduler = tempTimer;
        this.weatherTimeScheduler = weatherTimer;
        this.temperatureTimeScheduler.startTimerAtFixedRate(new TemperatureChanger(Optional.of(temperature)), Duration.ofSeconds(5));
        this.weatherTimeScheduler.startTimerAtFixedRate(new WeatherConditionsChanger(Optional.of(isSunny)), Duration.ofSeconds(35));
    }


    @Override
    public Receive<EnvironmentCommand> createReceive() {
        return newReceiveBuilder()
                //.onMessage(InitEnvironment.class, this:: onInitEnvironment)
                .onMessage(TemperatureChanger.class, this::onChangeTemperature)
                .onMessage(WeatherConditionsChanger.class, this::onChangeWeather)
                .onSignal(PostStop.class, signal -> onPostStop())
                .build();
    }

    /*
    private Behavior<EnvironmentCommand> onInitEnvironment(InitEnvironment i) {
        getContext().getLog().info("Start of environment");
        return this;
    }
*/

    private Behavior<EnvironmentCommand> onChangeTemperature(TemperatureChanger t) {

        //Temperature increases with every call until it reaches 25 then it will go back to step by step to 15
        if(setLowTemp && temperature < 25.0) {
            temperature = temperature + 1.0;
        }
        if(setHighTemp && temperature > 15.0){
            temperature = temperature - 1.0;
        }
        if(temperature == 25.0) {
            setLowTemp = false;
            setHighTemp = true;
        }
        if(temperature == 15.0) {
            setHighTemp = false;
            setLowTemp = true;
        }

        getContext().getLog().info("Environment received {}", temperature);
        this.temperatureSensor.tell(new TemperatureSensor.ReadTemperature(Optional.of(temperature)));
        return this;
    }

    private Behavior<EnvironmentCommand> onChangeWeather(WeatherConditionsChanger w) {
        getContext().getLog().info("Environment Change Sun to {}", !isSunny);
         isSunny = !isSunny;

         this.weatherSensor.tell(new WeatherSensor.ReadWeatherSunlight(Optional.of(isSunny)));
        return this;
    }


    private Environment onPostStop(){
        getContext().getLog().info("Environment actor stopped");
        return this;
    }
}


