package at.fhv.sysarch.lab2.homeautomation.devices;

import akka.actor.typed.ActorRef;
import akka.actor.typed.Behavior;
import akka.actor.typed.PostStop;
import akka.actor.typed.javadsl.AbstractBehavior;
import akka.actor.typed.javadsl.ActorContext;
import akka.actor.typed.javadsl.Behaviors;
import akka.actor.typed.javadsl.Receive;

import java.util.Optional;

public class MediaStation extends AbstractBehavior<MediaStation.MediaStationCommand> {

    public interface MediaStationCommand{}

    public static final class ReadMediaStationStatus implements MediaStationCommand {
        final Optional<Boolean> isActive;

        public ReadMediaStationStatus(Optional<Boolean> isActive) {
            this.isActive = isActive;
        }
    }

    public static Behavior<MediaStationCommand> create(ActorRef<Blinds.BlindsCommand> blinds, String groupID, String deviceID) {
        return Behaviors.setup(context -> new MediaStation(context, blinds, groupID, deviceID));
    }

    private final String groupID;
    private final String deviceID;
    private ActorRef<Blinds.BlindsCommand> blinds;

    public MediaStation(ActorContext<MediaStationCommand> context, ActorRef<Blinds.BlindsCommand> blinds, String groupID, String deviceID) {
        super(context);
        this.blinds = blinds;
        this.deviceID = deviceID;
        this.groupID = groupID;

        getContext().getLog().info("MediaStation started");
    }

    @Override
    public Receive<MediaStationCommand> createReceive() {
        return newReceiveBuilder()
                .onMessage(ReadMediaStationStatus.class, this::onReadMediaStationStatus)
                .onSignal(PostStop.class, signal -> onPostStop())
                .build();
    }

    private Behavior<MediaStationCommand> onReadMediaStationStatus(ReadMediaStationStatus r) {
        getContext().getLog().info("MediaStation received {}", r.isActive.get());
        this.blinds.tell(new Blinds.CommandFromMediaStation(r.isActive));
        return this;
    }

    private MediaStation onPostStop(){
        getContext().getLog().info("MediaStation actor {}-{} stopped", groupID, deviceID);
        return this;
    }



}
