package at.fhv.sysarch.lab2.homeautomation.devices;

import akka.actor.typed.ActorRef;
import akka.actor.typed.Behavior;
import akka.actor.typed.PostStop;
import akka.actor.typed.javadsl.AbstractBehavior;
import akka.actor.typed.javadsl.ActorContext;
import akka.actor.typed.javadsl.Behaviors;
import akka.actor.typed.javadsl.Receive;
import at.fhv.sysarch.lab2.homeautomation.fridge.Product;

import java.util.Optional;

public class OrderProcessor extends AbstractBehavior<OrderProcessor.OrderProcessorCommand> {


    public interface OrderProcessorCommand {}

    public static final class OrderForFridge implements OrderProcessorCommand {
        final Optional<Product> productToOrder;

        public OrderForFridge(Optional<Product> productToOrder) {
            this.productToOrder = productToOrder;
        }
    }

    public static final class RemoveForFridge implements OrderProcessorCommand {
        final Optional<Product> productToRemove;

        public RemoveForFridge(Optional<Product> productToRemove) {
            this.productToRemove = productToRemove;
        }
    }

    public static final class ResponseFromSpaceSensor implements OrderProcessorCommand {

    }

    public static final class ResponseFromWeightSensor implements OrderProcessorCommand {

    }


    public static final class Shutdown implements OrderProcessorCommand {

    }

    private final String groupID;
    private final String deviceID;
    private ActorRef<FridgeSpaceSensor.FridgeSpaceCommand> fridgeSpaceSensor;
    private ActorRef<FridgeWeightSensor.FridgeWeightCommand> fridgeWeightSensor;
    private ActorRef<Fridge.FridgeCommand> fridge;

    public static Behavior<OrderProcessorCommand> create(ActorRef<FridgeSpaceSensor.FridgeSpaceCommand> fridgeSpaceSensor,ActorRef<FridgeWeightSensor.FridgeWeightCommand> fridgeWeightSensor, ActorRef<Fridge.FridgeCommand> fridge,String groupID, String deviceID){
        return Behaviors.setup(context -> new OrderProcessor(context,fridgeSpaceSensor,fridgeWeightSensor, fridge, groupID,deviceID));
    }

    public OrderProcessor(ActorContext<OrderProcessorCommand> context, ActorRef<FridgeSpaceSensor.FridgeSpaceCommand> fridgeSpaceSensor,ActorRef<FridgeWeightSensor.FridgeWeightCommand> fridgeWeightSensor, ActorRef<Fridge.FridgeCommand> fridge, String groupID, String deviceID) {
        super(context);
        this.groupID = groupID;
        this.deviceID = deviceID;
        this.fridgeSpaceSensor = fridgeSpaceSensor;
        this.fridgeWeightSensor = fridgeWeightSensor;
        this.fridge = fridge;
        getContext().getLog().info("OrderProcessor started");
    }

    @Override
    public Receive<OrderProcessorCommand> createReceive() {
        return newReceiveBuilder()
                .onMessage(OrderForFridge.class, this::onOrder)
                .onMessage(Shutdown.class, message -> shutdown())
                .onMessage(RemoveForFridge.class, this::onRemove)
                .onMessage(ResponseFromSpaceSensor.class, this::onResponseSpace)
                .onMessage(ResponseFromWeightSensor.class, this::onResponseWeight)
                .onSignal(PostStop.class, signal -> onPostStop())
                .build();
    }

    private Behavior<OrderProcessorCommand> onOrder(OrderForFridge o) {

        Optional<Product> product = o.productToOrder;
        Optional<Double> weight = Optional.of(product.get().getWeight());
        this.fridgeSpaceSensor.tell(new FridgeSpaceSensor.AddSpace(Optional.of(Integer.valueOf(1)), this.getContext().getSelf()));
        this.fridgeWeightSensor.tell(new FridgeWeightSensor.AddWeight(weight, this.getContext().getSelf()));
        return this;
    }

    private Behavior<OrderProcessorCommand> onRemove(RemoveForFridge r) {
        Optional<Product> product = r.productToRemove;
        Optional<Double> weight = Optional.of(product.get().getWeight());
        this.fridgeSpaceSensor.tell(new FridgeSpaceSensor.SubSpace(Optional.of(Integer.valueOf(1)), this.getContext().getSelf()));
        this.fridgeWeightSensor.tell(new FridgeWeightSensor.SubWeight(weight, this.getContext().getSelf()));
        return this;
    }

    private Behavior<OrderProcessorCommand> shutdown() {
        getContext().getSystem().log().info("Kill Actor Process Order");
        return Behaviors.stopped();
    }

    private Behavior<OrderProcessorCommand> onResponseSpace(ResponseFromSpaceSensor r) {
        this.fridge.tell(new Fridge.OrderResponseSpace());
        return this;
    }

    private Behavior<OrderProcessorCommand> onResponseWeight(ResponseFromWeightSensor r) {
        this.fridge.tell(new Fridge.OrderResponseWeight());
        return this;
    }

    private OrderProcessor onPostStop() {
        getContext().getLog().info("OrderProcessor actor {}-{} stopped", groupID, deviceID);
        return this;
    }


}
