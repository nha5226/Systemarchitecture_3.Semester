package at.fhv.sysarch.lab2.homeautomation.devices;

import akka.actor.typed.ActorRef;
import akka.actor.typed.Behavior;
import akka.actor.typed.PostStop;
import akka.actor.typed.javadsl.AbstractBehavior;
import akka.actor.typed.javadsl.ActorContext;
import akka.actor.typed.javadsl.Behaviors;
import akka.actor.typed.javadsl.Receive;

import java.util.Optional;

public class WeatherSensor extends AbstractBehavior<WeatherSensor.WeatherSensorCommand> {

    public interface WeatherSensorCommand{}

    public static final class ReadWeatherSunlight implements WeatherSensorCommand{
        final Optional<Boolean> isSunny;

        public ReadWeatherSunlight (Optional<Boolean> isSunny) {
            this.isSunny = isSunny;
        }
    }


    public static Behavior<WeatherSensorCommand> create(ActorRef<Blinds.BlindsCommand> blinds, String groupID, String deviceID) {
        return Behaviors.setup(context -> new WeatherSensor(context, blinds, groupID, deviceID));
    }

    private final String groupID;
    private final String deviceID;
    private ActorRef<Blinds.BlindsCommand> blinds;

    public WeatherSensor(ActorContext<WeatherSensorCommand> context, ActorRef<Blinds.BlindsCommand> blinds, String groupID, String deviceID) {
        super(context);
        this.blinds = blinds;
        this.groupID = groupID;
        this.deviceID = deviceID;

        getContext().getLog().info("WeatherSensor started");
    }

    @Override
    public Receive<WeatherSensorCommand> createReceive() {
        return newReceiveBuilder()
                .onMessage(ReadWeatherSunlight.class, this::onReadSunlight)
                .onSignal(PostStop.class, signal -> onPostStop())
                .build();
    }

    private Behavior<WeatherSensorCommand> onReadSunlight(ReadWeatherSunlight r) {
        getContext().getLog().info("WeatherSensor received {}", r.isSunny.get());
        this.blinds.tell(new Blinds.CommandFromWeatherStation(r.isSunny));
        return this;
    }


    private WeatherSensor onPostStop(){
        getContext().getLog().info("WeatherSensor actor {}-{} stopped", groupID, deviceID);
        return this;
    }
}
