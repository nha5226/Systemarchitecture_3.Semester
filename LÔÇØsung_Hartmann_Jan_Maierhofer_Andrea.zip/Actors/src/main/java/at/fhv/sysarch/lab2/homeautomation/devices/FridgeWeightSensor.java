package at.fhv.sysarch.lab2.homeautomation.devices;

import akka.actor.typed.ActorRef;
import akka.actor.typed.Behavior;
import akka.actor.typed.PostStop;
import akka.actor.typed.javadsl.AbstractBehavior;
import akka.actor.typed.javadsl.ActorContext;
import akka.actor.typed.javadsl.Behaviors;
import akka.actor.typed.javadsl.Receive;

import java.util.Optional;
import java.util.OptionalInt;

public class FridgeWeightSensor extends AbstractBehavior<FridgeWeightSensor.FridgeWeightCommand> {



    public interface FridgeWeightCommand{}

    public static final class AddWeight implements FridgeWeightCommand {
        final Optional<Double> additionalWeight;
        final ActorRef<OrderProcessor.OrderProcessorCommand> orderProcessor;

        public AddWeight(Optional<Double> additionalWeight, ActorRef<OrderProcessor.OrderProcessorCommand> orderProcessor) {
            this.additionalWeight = additionalWeight;
            this.orderProcessor = orderProcessor;
        }
    }

    public static final class SubWeight implements FridgeWeightCommand{
        final Optional<Double> subtractionalWeight;
        final ActorRef<OrderProcessor.OrderProcessorCommand> orderProcessor;

        public SubWeight(Optional<Double> subtractionalWeight, ActorRef<OrderProcessor.OrderProcessorCommand> orderProcessor) {
            this.subtractionalWeight = subtractionalWeight;
            this.orderProcessor = orderProcessor;
        }
    }

    public static final class Weight implements FridgeWeightCommand {
        final ActorRef<Fridge.FridgeCommand> fridge;

        public Weight(ActorRef<Fridge.FridgeCommand> fridge) {
            this.fridge = fridge;
        }

    }



    private final String groupID;
    private final String deviceID;
    private Double weight = 0.0;

    public static Behavior<FridgeWeightCommand> create(String groupID, String deviceID) {
        return Behaviors.setup(context -> new FridgeWeightSensor(context, groupID, deviceID));
    }

    public FridgeWeightSensor(ActorContext<FridgeWeightCommand> context, String groupID, String deviceID) {
        super(context);

        this.groupID = groupID;
        this.deviceID = deviceID;
    }

    @Override
    public Receive<FridgeWeightCommand> createReceive() {
        return newReceiveBuilder()
                .onMessage(AddWeight.class, this::onAddWeight)
                .onMessage(SubWeight.class, this::onSubWeight)
                .onMessage(Weight.class, this::onWeight)
                .onSignal(PostStop.class, signal -> onPostStop())
                .build();
    }

    public Behavior<FridgeWeightCommand> onAddWeight(AddWeight a) {
        getContext().getLog().info("FridgeWeight increases {}", a.additionalWeight.get());
        Optional<Double> weightOfProduct = a.additionalWeight;
        weight = this.weight + weightOfProduct.get();

        Optional<Double> newWeight = Optional.of(weight);
        a.orderProcessor.tell(new OrderProcessor.ResponseFromWeightSensor());
        return this;
    }

    public Behavior<FridgeWeightCommand> onSubWeight(SubWeight s) {
        getContext().getLog().info("FridgeWEight decreases {}", s.subtractionalWeight.get());
        Optional<Double> weightOfProduct = s.subtractionalWeight;
        weight = this.weight - weightOfProduct.get();
        Optional<Double> newWeight = Optional.of(weight);
        s.orderProcessor.tell(new OrderProcessor.ResponseFromWeightSensor());
        return this;
    }

    public Behavior<FridgeWeightCommand> onWeight(Weight w) {
        w.fridge.tell(new Fridge.WeightCommand(Optional.of(weight)));
        return this;
    }

    private FridgeWeightSensor onPostStop() {
        getContext().getLog().info("FridgeWeightSensor actor {}-{} stopped", groupID, deviceID);
        return this;
    }
}
