package at.fhv.sysarch.lab2.homeautomation.devices;

import akka.actor.typed.ActorRef;
import akka.actor.typed.Behavior;
import akka.actor.typed.PostStop;
import akka.actor.typed.javadsl.AbstractBehavior;
import akka.actor.typed.javadsl.ActorContext;
import akka.actor.typed.javadsl.Behaviors;
import akka.actor.typed.javadsl.Receive;
import at.fhv.sysarch.lab2.homeautomation.fridge.Order;
import at.fhv.sysarch.lab2.homeautomation.fridge.Product;

import java.util.LinkedList;
import java.util.List;
import java.util.Optional;

public class Fridge extends AbstractBehavior<Fridge.FridgeCommand> {



    public interface FridgeCommand {}

    public static final class OrderProduct implements FridgeCommand {
        final Optional<Product> product;

        public OrderProduct(Optional<Product> product) {
            this.product = product;
        }
    }

    public static final class RemoveProduct implements FridgeCommand {
        final Optional<Product> product;

        public RemoveProduct(Optional<Product> product) {
            this.product = product;
        }
    }

    public static final class WeightCommand implements FridgeCommand {
        final Optional<Double> weight;

        public WeightCommand(Optional<Double> weight) {
            this.weight = weight;
        }
    }

    public static final class SpaceCommand implements FridgeCommand {
        final Optional<Integer> space;

        public SpaceCommand(Optional<Integer> space) {
            this.space = space;
        }
    }

    public static final class OrderResponseSpace implements FridgeCommand {
    }

    public static final class OrderResponseWeight implements FridgeCommand {
    }

    public static final class QueryingStoredProducts implements FridgeCommand {
    }

    public static final class QueryingOrderHistory implements FridgeCommand {
    }

    private final String groupId;
    private final String deviceId;
    private final List<Product> products;
    private final List<Order> orders;
    private final Integer maxSpace;
    private final Double maxWeight;
    private ActorRef<FridgeWeightSensor.FridgeWeightCommand> fridgeWeightSensor;
    private ActorRef<FridgeSpaceSensor.FridgeSpaceCommand> fridgeSpaceSensor;

    private Integer space;
    private Double weight;

    private ActorRef<OrderProcessor.OrderProcessorCommand> orderProcessor;
    boolean terminate = false;


    public static Behavior<FridgeCommand> create(String groupId, String deviceId, Integer maxSpace, Double maxWeight) {
        return Behaviors.setup(context -> new Fridge(context, groupId, deviceId,maxSpace, maxWeight));
    }

    public Fridge(ActorContext<FridgeCommand> context,String groupId, String deviceId,Integer maxSpace, Double maxWeight) {
        super(context);
        this.groupId = groupId;
        this.deviceId = deviceId;
        this.products = new LinkedList<>();
        this.orders = new LinkedList<>();
        this.space = 0;
        this.weight = 0.0;
        this.maxSpace = maxSpace;
        this.maxWeight = maxWeight;
        this.fridgeWeightSensor = getContext().spawn(FridgeWeightSensor.create( "1", "1"), "fridgeWeightSensor");
        this.fridgeSpaceSensor = getContext().spawn(FridgeSpaceSensor.create( "1", "1"), "fridgeSpaceSensor");
        getContext().getLog().info("Fridge started");
    }

    @Override
    public Receive<FridgeCommand> createReceive() {
        return newReceiveBuilder()
                .onMessage(OrderProduct.class, this::onOrderProduct)
                .onMessage(RemoveProduct.class, this::onRemoveProduct)
                .onMessage(WeightCommand.class, this::onReadWeight)
                .onMessage(SpaceCommand.class, this::onReadSpace)
                .onMessage(OrderResponseWeight.class, this::onOrderResponseWeight)
                .onMessage(OrderResponseSpace.class, this::onOrderResponseSpace)
                .onMessage(QueryingStoredProducts.class, this::onQueryingStoredProducts)
                .onMessage(QueryingOrderHistory.class, this::onQueryingOrderHistroy)
                .onSignal(PostStop.class, signal -> onPostStop())
                .build();

    }


    public Behavior<FridgeCommand> onOrderProduct(OrderProduct o) {
        getContext().getLog().info("Order Product {}", o.product.get().getProductname());

        Product p = o.product.get();

        if((p.getWeight()+this.weight) <= this.maxWeight && (space+1) <= this.maxSpace) {
            //create new OrderProcess ChildActor
            products.add(p);
            orders.add(new Order(p));
            orderProcessor = getContext().spawn(OrderProcessor.create(fridgeSpaceSensor,fridgeWeightSensor, this.getContext().getSelf(), "1","1"), "orderProcessorOrder");
            orderProcessor.tell(new OrderProcessor.OrderForFridge(o.product));


        } else {
            getContext().getLog().info("Could not Order Product, Fridge is Full");
        }

        return this;
    }

    public Behavior<FridgeCommand> onRemoveProduct(RemoveProduct r) {
        getContext().getLog().info("Remove Product {}", r.product.get().getProductname());

        Product p = r.product.get();
        if(products.contains(p)) {
            products.remove(p);
            //Orderprocess remove
            ActorRef<OrderProcessor.OrderProcessorCommand> orderProcessor = getContext().spawn(OrderProcessor.create(fridgeSpaceSensor,fridgeWeightSensor, this.getContext().getSelf(), "1","1"), "orderProcessorRemove");
            orderProcessor.tell(new OrderProcessor.RemoveForFridge(r.product));

            int productCounter = 0;
            for(Product product : products) {
                if(product.getProductname().equals(p.getProductname())) {
                    productCounter++;
                }
            }
            if(productCounter == 0) {
                onOrderProduct(new OrderProduct(r.product));
            }
            orderProcessor.tell(new OrderProcessor.Shutdown());

        } else {
            getContext().getLog().info("Dude you already ate that {}", p.getProductname());
        }

        return this;
    }

    public Behavior<FridgeCommand> onReadWeight(WeightCommand w) {
        getContext().getLog().info("Fridge gets new Weight {}", w.weight.get());
        this.weight = w.weight.get();
        return this;
    }

    public Behavior<FridgeCommand> onReadSpace(SpaceCommand s) {
        getContext().getLog().info("Fridge gets new Space {}", s.space.get());
        this.space = s.space.get();
        return this;
    }

    public Behavior<FridgeCommand> onOrderResponseSpace(OrderResponseSpace o) {
        fridgeSpaceSensor.tell(new FridgeSpaceSensor.Space(this.getContext().getSelf()));
        if(terminate) {
            orderProcessor.tell(new OrderProcessor.Shutdown());
            terminate = false;
        } else {
            terminate = true;
        }

        return this;
    }

    public Behavior<FridgeCommand> onOrderResponseWeight(OrderResponseWeight o) {
        fridgeWeightSensor.tell(new FridgeWeightSensor.Weight(this.getContext().getSelf()));

        if(terminate) {
            orderProcessor.tell(new OrderProcessor.Shutdown());
            terminate = false;
        } else {
            terminate = true;
        }


        return this;
    }

    public Behavior<FridgeCommand> onQueryingOrderHistroy(QueryingOrderHistory q) {

        for(Order o : orders) {
            getContext().getLog().info(o.toString());
        }
        return this;
    }

    public Behavior<FridgeCommand> onQueryingStoredProducts(QueryingStoredProducts q) {

        for(Product p : products) {
            getContext().getLog().info(p.toString());
        }
        return this;
    }


    private Fridge onPostStop() {
        getContext().getLog().info("Fridge actor {}-{} stopped", groupId, deviceId);
        return this;
    }

}
