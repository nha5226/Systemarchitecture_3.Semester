package at.fhv.sysarch.lab2.homeautomation.devices;

import akka.actor.typed.Behavior;
import akka.actor.typed.PostStop;
import akka.actor.typed.javadsl.AbstractBehavior;
import akka.actor.typed.javadsl.ActorContext;
import akka.actor.typed.javadsl.Behaviors;
import akka.actor.typed.javadsl.Receive;

import java.util.Optional;

public class Blinds extends AbstractBehavior<Blinds.BlindsCommand> {

    public interface BlindsCommand {}

    public static final class CommandFromMediaStation implements BlindsCommand {
        final Optional<Boolean> isMoviePlaying;

        public CommandFromMediaStation(Optional<Boolean> isMoviePlaying){
            this.isMoviePlaying = isMoviePlaying;
        }
    }

    public static final class CommandFromWeatherStation implements BlindsCommand {
        final Optional<Boolean> isSunny;

        public CommandFromWeatherStation(Optional<Boolean> isSunny) {
            this.isSunny = isSunny;
        }
    }

    private final String groupID;
    private final String deviceID;
    private boolean isOpen;
    private boolean mediaStationIsActive;

    public Blinds(ActorContext<BlindsCommand> context, String groupID, String deviceID) {
        super(context);
        this.groupID = groupID;
        this.deviceID = deviceID;
        getContext().getLog().info("Blinds started");
    }

    public static Behavior<BlindsCommand> create(String groupID, String deviceID) {
        return Behaviors.setup(context -> new Blinds(context, groupID, deviceID));
    }

    @Override
    public Receive<BlindsCommand> createReceive() {
        return newReceiveBuilder()
                .onMessage(CommandFromWeatherStation.class, this::onReadWeatherSensor)
                .onMessage(CommandFromMediaStation.class, this::onMediaStationActive)
                .onSignal(PostStop.class, signal -> onPostStop())
                .build();
    }

    private Behavior<BlindsCommand> onReadWeatherSensor(CommandFromWeatherStation c){
        getContext().getLog().info("Blinds reading  {}", c.isSunny.get());
        if(c.isSunny.get()){
            this.isOpen = false;
            getContext().getLog().info("Blinds closed");
        }
        else {
            this.isOpen = true;
            getContext().getLog().info("Blinds opened");

        }
        return Behaviors.same();
    }

    private Behavior<BlindsCommand> onMediaStationActive(CommandFromMediaStation c) {

        if(c.isMoviePlaying.get() == true){
            getContext().getLog().info("Blinds closed, Movie started");

            this.mediaStationIsActive = true;
            this.isOpen = false;
            return Behaviors.receive(BlindsCommand.class)
                    .onMessage(CommandFromMediaStation.class, this::onMediaStationDeactivate)
                    .onSignal(PostStop.class, signal -> onPostStop())
                    .build();
        }
        return this;
    }

    private Behavior<BlindsCommand> onMediaStationDeactivate(CommandFromMediaStation c) {
        getContext().getLog().info("Turning Blinds to {}", c.isMoviePlaying);

        if(c.isMoviePlaying.get() == false) {
            getContext().getLog().info("Blinds opened, Movie stopped");
            this.mediaStationIsActive = false;
            this.isOpen = true;
            return Behaviors.receive(BlindsCommand.class)
                    .onMessage(CommandFromMediaStation.class, this::onMediaStationActive)
                    .onMessage(CommandFromWeatherStation.class, this::onReadWeatherSensor)
                    .onSignal(PostStop.class, signal -> onPostStop())
                    .build();
        }

        return this;
    }

    private Blinds onPostStop() {
        getContext().getLog().info("Media Station active, Blinds are closed");
        return this;
    }
}
